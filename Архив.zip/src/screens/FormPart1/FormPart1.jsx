import React, { useState } from "react";
import { Link } from "react-router-dom";
import Button from "../../components/Button/Button";
import Input from "../../components/Input/Input";
import css from './FormPart1.module.css';
import Back from '../../components/Back/Back';
import Select from "../../components/Select/Select";

const Enter = () => {
    const [sentCode, setsentCode] = useState(false)
    return (
        <div className={css.base_container}>
            <Back to='/enter' />
            <div className={css.header}>Заполните <br />анкету</div>
            <div className={css.inputs}>
                <div className={css.formInput}>
                    <Input label='Фамилия*' type='text' valid />
                </div>
                <div className={css.formInput}>
                    <Input label='Имя*' type='text' valid />
                </div>
                <div className={css.formInput}>
                    <Input label='Отчество*' type='text' valid />
                </div>
                <div className={css.formInput}>
                    <Input label='Дата рождения*' type='date' valid />
                </div>
                <div className={css.formInput}>
                    <Input label='Номер телефона*' type='number' />
                </div>
                {
                    !sentCode ? (
                        <div className={css.buttons}>
                            <Link
                                className={css.buttons}
                                onClick={() => setsentCode(true)}
                            >Подтвердить номер</Link>
                        </div>
                    ) : (
                        <div className={css.formInput}>
                            <Input label='Введите код подтверждения' type='number' />
                        </div>
                    )
                }
                <div className={css.formInput}>
                    <Input label='E-mail*' type='email' />
                </div>
                <div className={css.formInput}>
                    <Input label='Пароль*' type='password' />
                </div>
            </div>
            <div className={css.selects}>
                <div className={css.formSelect}>
                    <Select label='Статус*' options={["Гость","Преподаватель", "Студент"]} />
                </div>
                <div className={css.formSelect}>
                    <Select label='ВУЗ*' options={["НИ ТГУ","НИ ТПУ", "ТУСУР"]}/>
                </div>
            </div>
            <div className={css.enterBtn}>
                <Button to='/formPart2'>Далее</Button>
            </div>
        </div>
    )
}

export default Enter;